
import React from 'react';
import type { ClassificationResult } from '../types';
import { DogIcon, CatIcon, ScienceIcon, AlertTriangleIcon } from './icons';

interface ClassificationResultDisplayProps {
  result: ClassificationResult | null;
  isLoading: boolean;
  error: string | null;
  uploadedImage: string | null;
}

const SVMVisualization: React.FC<{ result: ClassificationResult | null }> = ({ result }) => {
    const isDog = result?.classification === 'Dog';
    const isCat = result?.classification === 'Cat';
    const classificationOffset = isDog ? -40 : isCat ? 40 : 0;
    const confidence = result?.confidence ?? 0;

    return (
        <div className="w-full p-4 bg-gray-900/50 rounded-lg">
            <h4 className="text-sm font-semibold text-gray-400 mb-2 text-center">SVM Hyperplane Visualization</h4>
            <svg viewBox="0 0 200 100" className="w-full">
                <defs>
                    <radialGradient id="dogGradient">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#2563eb" />
                    </radialGradient>
                    <radialGradient id="catGradient">
                        <stop offset="0%" stopColor="#f97316" />
                        <stop offset="100%" stopColor="#ea580c" />
                    </radialGradient>
                    <radialGradient id="unknownGradient">
                        <stop offset="0%" stopColor="#8b5cf6" />
                        <stop offset="100%" stopColor="#7c3aed" />
                    </radialGradient>
                </defs>

                {/* Data points */}
                <circle cx="40" cy="30" r="3" fill="#3b82f6" opacity="0.7" />
                <circle cx="25" cy="50" r="3" fill="#3b82f6" opacity="0.7" />
                <circle cx="50" cy="70" r="3" fill="#3b82f6" opacity="0.7" />
                <circle cx="60" cy="40" r="3" fill="#3b82f6" opacity="0.7" />

                <circle cx="160" cy="35" r="3" fill="#f97316" opacity="0.7" />
                <circle cx="175" cy="55" r="3" fill="#f97316" opacity="0.7" />
                <circle cx="150" cy="75" r="3" fill="#f97316" opacity="0.7" />
                <circle cx="140" cy="45" r="3" fill="#f97316" opacity="0.7" />

                {/* Hyperplane and margins */}
                <line x1="100" y1="10" x2="100" y2="90" stroke="#a78bfa" strokeWidth="1.5" />
                <line x1="80" y1="10" x2="80" y2="90" stroke="#a78bfa" strokeWidth="0.5" strokeDasharray="2,2" />
                <line x1="120" y1="10" x2="120" y2="90" stroke="#a78bfa" strokeWidth="0.5" strokeDasharray="2,2" />

                {/* Labels */}
                <text x="40" y="95" fontSize="8" fill="#3b82f6" textAnchor="middle">Dogs</text>
                <text x="160" y="95" fontSize="8" fill="#f97316" textAnchor="middle">Cats</text>

                {/* Classified point */}
                {result && (
                    <g className="transition-transform duration-1000 ease-out" style={{ transform: `translateX(${classificationOffset}px)` }}>
                        <circle cx="100" cy="50" r={4 + confidence * 4} 
                            fill={isDog ? "url(#dogGradient)" : isCat ? "url(#catGradient)" : "url(#unknownGradient)"}
                            className="transition-all duration-500"
                            stroke="white" strokeWidth="1" />
                    </g>
                )}
            </svg>
        </div>
    );
};


const ClassificationResultDisplay: React.FC<ClassificationResultDisplayProps> = ({ result, isLoading, error, uploadedImage }) => {
  const hasResult = !!result;
  const isDog = result?.classification === 'Dog';
  const isCat = result?.classification === 'Cat';

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center text-center gap-4 h-full">
           <div className="relative w-20 h-20">
              <DogIcon className="absolute w-full h-full text-blue-500 animate-ping opacity-50"/>
              <CatIcon className="absolute w-full h-full text-orange-500 animate-pulse"/>
           </div>
          <p className="text-xl font-semibold text-gray-300">Classifying animal...</p>
          <p className="text-gray-400">The model is analyzing the image.</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center gap-4 bg-red-900/20 p-6 rounded-lg h-full">
          <AlertTriangleIcon className="w-16 h-16 text-red-400"/>
          <p className="text-xl font-semibold text-red-300">Classification Error</p>
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      );
    }
    
    if (!hasResult && !uploadedImage) {
         return (
        <div className="flex flex-col items-center justify-center text-center gap-4 h-full">
          <ScienceIcon className="w-16 h-16 text-gray-600"/>
          <p className="text-xl font-semibold text-gray-400">Awaiting Image</p>
          <p className="text-gray-500">Upload an image to see the classification result here.</p>
        </div>
      );
    }
    
    if (!hasResult && uploadedImage) {
         return (
        <div className="flex flex-col items-center justify-center text-center gap-4 h-full">
          <ScienceIcon className="w-16 h-16 text-cyan-500"/>
          <p className="text-xl font-semibold text-gray-300">Ready to Classify</p>
          <p className="text-gray-400">Click the "Classify Image" button to begin.</p>
        </div>
      );
    }


    if (result) {
      const confidencePercentage = (result.confidence * 100).toFixed(1);
      const isUnknown = result.classification === 'Unknown';
      const resultColorClass = isDog ? 'text-blue-400' : isCat ? 'text-orange-400' : 'text-purple-400';
      const resultIcon = isDog ? <DogIcon className="w-10 h-10"/> : isCat ? <CatIcon className="w-10 h-10"/> : <AlertTriangleIcon className="w-10 h-10"/>;

      return (
        <div className="flex flex-col gap-4">
          <div className={`p-4 rounded-lg bg-gray-900/50 flex items-center justify-center gap-4`}>
            <div className={`${resultColorClass}`}>{resultIcon}</div>
            <div className="text-center">
              <p className="text-sm text-gray-400">Classification</p>
              <p className={`text-3xl font-bold ${resultColorClass}`}>{isUnknown ? "Not a Cat or Dog" : `It's a ${result.classification}!`}</p>
            </div>
          </div>
          <div className="p-4 rounded-lg bg-gray-900/50">
            <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium text-gray-400">Confidence</span>
                <span className={`text-sm font-semibold ${resultColorClass}`}>{confidencePercentage}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div className={`${isDog ? 'bg-blue-500' : isCat ? 'bg-orange-500' : 'bg-purple-500'} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${confidencePercentage}%` }}></div>
            </div>
          </div>
          <SVMVisualization result={result} />
        </div>
      );
    }

    return null;
  };

  return (
    <div className="w-full aspect-square bg-gray-800 rounded-lg p-4 flex items-center justify-center">
      {renderContent()}
    </div>
  );
};

export default ClassificationResultDisplay;
