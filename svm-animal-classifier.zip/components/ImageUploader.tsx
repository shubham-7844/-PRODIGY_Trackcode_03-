
import React, { useRef } from 'react';
import { UploadIcon, DogIcon, CatIcon } from './icons';

interface ImageUploaderProps {
  imageDataUrl: string | null;
  onImageChange: (file: File | null) => void;
  onClassify: () => void;
  isLoading: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ imageDataUrl, onImageChange, onClassify, isLoading }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    onImageChange(file);
  };

  const handleDropzoneClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };
  
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0] || null;
    onImageChange(file);
  };

  return (
    <div className="flex flex-col gap-4">
      <div 
        className="relative w-full aspect-square bg-gray-900 rounded-lg border-2 border-dashed border-gray-600 flex items-center justify-center cursor-pointer hover:border-fuchsia-500 transition-colors duration-300 group"
        onClick={handleDropzoneClick}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png, image/jpeg, image/webp"
          className="hidden"
          onChange={handleFileSelect}
        />
        {imageDataUrl ? (
          <img src={imageDataUrl} alt="Preview" className="w-full h-full object-cover rounded-lg" />
        ) : (
          <div className="text-center text-gray-500 flex flex-col items-center gap-2">
            <UploadIcon className="w-12 h-12 mb-2 text-gray-600 group-hover:text-fuchsia-500 transition-colors" />
            <span className="font-semibold">Click or Drag & Drop Image</span>
            <span className="text-sm">PNG, JPG, or WEBP</span>
          </div>
        )}
      </div>
      <button
        onClick={onClassify}
        disabled={isLoading || !imageDataUrl}
        className="w-full bg-fuchsia-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-fuchsia-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-3 text-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:ring-offset-2 focus:ring-offset-gray-900"
      >
        {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Classifying...
            </>
        ) : (
          <>
            <DogIcon className="w-6 h-6" /> Classify Image <CatIcon className="w-6 h-6" />
          </>
        )}
      </button>
    </div>
  );
};

export default ImageUploader;
