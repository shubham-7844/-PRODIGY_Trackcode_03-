
import { GoogleGenAI, Type } from "@google/genai";
import type { ClassificationResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const classificationSchema = {
  type: Type.OBJECT,
  properties: {
    classification: {
      type: Type.STRING,
      description: "The classification of the animal. Should be 'Cat', 'Dog', or 'Unknown' if neither is clearly identifiable.",
      enum: ['Cat', 'Dog', 'Unknown'],
    },
    confidence: {
      type: Type.NUMBER,
      description: "A confidence score for the classification, ranging from 0.0 to 1.0.",
    },
  },
  required: ["classification", "confidence"],
};

export const classifyImage = async (base64Data: string, mimeType: string): Promise<ClassificationResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            text: "You are an expert in animal classification. Analyze the provided image and determine if it contains a cat or a dog. Provide your classification and a confidence score. If the image does not contain a cat or a dog, classify as 'Unknown'.",
          },
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType,
            },
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: classificationSchema,
      },
    });

    const jsonString = response.text.trim();
    const parsedResult = JSON.parse(jsonString) as ClassificationResult;

    // Validate the parsed result
    if (
      (parsedResult.classification === 'Cat' || parsedResult.classification === 'Dog' || parsedResult.classification === 'Unknown') &&
      typeof parsedResult.confidence === 'number' &&
      parsedResult.confidence >= 0 &&
      parsedResult.confidence <= 1
    ) {
      return parsedResult;
    } else {
      console.error("Gemini API returned data in an unexpected format:", parsedResult);
      throw new Error("Received invalid classification data from the API.");
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to classify image. The API call may have failed or returned an unexpected response.");
  }
};
