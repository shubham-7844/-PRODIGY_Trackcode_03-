
import React, { useState, useCallback } from 'react';
import type { ClassificationResult } from './types';
import { classifyImage } from './services/geminiService';
import ImageUploader from './components/ImageUploader';
import ClassificationResultDisplay from './components/ClassificationResultDisplay';
import { PawPrintIcon } from './components/icons';

const App: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (file: File | null) => {
    setImageFile(file);
    setResult(null);
    setError(null);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageDataUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setImageDataUrl(null);
    }
  };

  const handleClassify = useCallback(async () => {
    if (!imageDataUrl) {
      setError("Please select an image first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      // Extract base64 data and mimeType from data URL
      const parts = imageDataUrl.split(',');
      if (parts.length !== 2) {
        throw new Error("Invalid Data URL format.");
      }
      const mimeType = parts[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
      const base64Data = parts[1];

      const classificationResult = await classifyImage(base64Data, mimeType);
      setResult(classificationResult);

    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "An unknown error occurred during classification.";
      console.error(e);
      setError(`Classification failed: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  }, [imageDataUrl]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center justify-center p-4 selection:bg-fuchsia-500 selection:text-white">
      <main className="w-full max-w-4xl mx-auto p-4 md:p-8 bg-gray-800/50 rounded-2xl shadow-2xl border border-gray-700 backdrop-blur-sm">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-2">
            <PawPrintIcon className="w-10 h-10 text-fuchsia-400"/>
             <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-fuchsia-500 to-cyan-400 text-transparent bg-clip-text">
              SVM Animal Classifier
            </h1>
          </div>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Upload an image of a cat or a dog. Our Gemini-powered model will classify it, simulating a Support Vector Machine decision boundary.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <ImageUploader
            imageDataUrl={imageDataUrl}
            onImageChange={handleImageChange}
            onClassify={handleClassify}
            isLoading={isLoading}
          />
          <ClassificationResultDisplay
            result={result}
            isLoading={isLoading}
            error={error}
            uploadedImage={imageDataUrl}
          />
        </div>
      </main>
      <footer className="text-center mt-8 text-gray-500 text-sm">
        <p>Powered by React, Tailwind CSS, and the Google Gemini API.</p>
      </footer>
    </div>
  );
};

export default App;
