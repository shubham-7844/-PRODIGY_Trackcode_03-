
export interface ClassificationResult {
  classification: 'Cat' | 'Dog' | 'Unknown';
  confidence: number;
}
